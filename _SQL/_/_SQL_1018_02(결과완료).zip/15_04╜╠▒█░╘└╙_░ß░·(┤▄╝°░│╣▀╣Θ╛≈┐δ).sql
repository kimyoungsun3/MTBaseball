/*

-- mtxxxx3 <- mtxxxx2 ��������
delete from dbo.tSingleGame 	where gameid = 'mtxxxx3' and curturntime in ( 830094, 830093, 830092, 829540, 829538, 829537, 829534, 829533, 828644, 828643 )
delete from dbo.tSingleGameLog 	where gameid = 'mtxxxx3' and curturntime in ( 830094, 830093, 830092, 829540, 829538, 829537, 829534, 829533, 828644, 828643 )
insert into tSingleGame (
							gameid,
							curturntime, curturndate, gamemode, consumeitemcode, select1, cnt1,
							select2, cnt2,
							select3, cnt3,
							select4, cnt4,
							selectdata, writedate, connectip, level, exp, commissionbet, gamestate
						)
select
							'mtxxxx3',
							curturntime, curturndate, gamemode, consumeitemcode, select1, cnt1,
							select2, cnt2,
							select3, cnt3,
							select4, cnt4,
							selectdata, writedate, connectip, level, exp, commissionbet, gamestate
from dbo.tSingleGame where gameid = 'mtxxxx2' and curturntime in ( 830094, 830093, 830092, 829540, 829538, 829537, 829534, 829533, 828644, 828643 )

*/


/*

-- mtxxxx3 -> mtxxxx2 ���
--delete from dbo.tSingleGame 	where gameid = 'mtxxxx2' and curturntime in ( 830094, 830093, 830092, 829540, 829538, 829537, 829534, 829533, 828644, 828643 )
--delete from dbo.tSingleGameLog 	where gameid = 'mtxxxx2' and curturntime in ( 830094, 830093, 830092, 829540, 829538, 829537, 829534, 829533, 828644, 828643 )
insert into tSingleGame (
							gameid,
							curturntime, curturndate, gamemode, consumeitemcode, select1, cnt1,
							select2, cnt2,
							select3, cnt3,
							select4, cnt4,
							selectdata, writedate, connectip, level, exp, commissionbet, gamestate
						)
select
							'mtxxxx2',
							curturntime, curturndate, gamemode, consumeitemcode, select1, cnt1,
							select2, cnt2,
							select3, cnt3,
							select4, cnt4,
							selectdata, writedate, connectip, level, exp, commissionbet, gamestate
from dbo.tSingleGame where gameid = 'mtxxxx3' and curturntime in ( 830094, 830093, 830092, 829540, 829538, 829537, 829534, 829533, 828644, 828643 )

*/


/*
-- mtxxxx3 -> mtxxxx2 ���
delete from dbo.tSingleGame 	where gameid = 'mtxxxx2' and curturntime in ( 830094 )
delete from dbo.tSingleGameLog 	where gameid = 'mtxxxx2' and curturntime in ( 830094 )
insert into tSingleGame (
							gameid,
							curturntime, curturndate, gamemode, consumeitemcode, select1, cnt1,
							select2, cnt2,
							select3, cnt3,
							select4, cnt4,
							selectdata, writedate, connectip, level, exp, commissionbet, gamestate
						)
select
							'mtxxxx2',
							curturntime, curturndate, gamemode, consumeitemcode, select1, cnt1,
							select2, cnt2,
							select3, cnt3,
							select4, cnt4,
							selectdata, writedate, connectip, level, exp, commissionbet, gamestate
from dbo.tSingleGame where gameid = 'mtxxxx3' and curturntime in ( 830094 )

*/