
declare @gamecost		int
declare @rand			int
declare @select 		varchar(100)
declare @curturntime 	int				set @curturntime 	= 830092
declare @gameid 		varchar(20)		set @gameid			= 'mtxxxx4'
declare @dateid8 		varchar(8)		set @dateid8 		= Convert(varchar(8),Getdate(),112)
update dbo.tUserMaster set gamecost = 1000, connectip = '127.0.0.6', exp = 0, level = 1 where gameid = 'mtxxxx4'
delete from dbo.tSingleGame where gameid = @gameid 
delete from dbo.tSingleGameLog where gameid = @gameid
update dbo.tPCRoomEarnMaster set gamecost = 0, cnt = 0 where dateid8 = @dateid8
update dbo.tPCRoomEarnSub set gamecost 	= 0, cnt  = 0 where dateid8 = @dateid8
delete from dbo.tSingleGameEarnLogMaster where dateid8 = @dateid8 
update dbo.tUserMaster set gamecost = 0, gaingamecost = 0, gaingamecostpc = 0 where gameid = 'mtxxxx4'
update dbo.tUserMaster set gamecost = 0, gaingamecost = 0, gaingamecostpc = 0 where gameid = 'xxxx'

declare curSingleGameSimule Cursor for
--select curturntime from dbo.tLottoInfo 
select top 1 curturntime from dbo.tLottoInfo 
--where curturntime in (830673, 830672)
order by curturntime asc
-- select count(*) from dbo.tLottoInfo
-- select * from dbo.tSingleGameEarnLogMaster

Open curSingleGameSimule
Fetch next from curSingleGameSimule into @curturntime
while @@Fetch_status = 0
	Begin
		set @rand = dbo.fnu_GetRandom(0, 8)

		----------------------------------------------
		-- 1. ����
		-- select=��ȣ:select:cnt;
		--        [1���ڸ�] : STRIKE( 0 ) : ����(1) )
		----------------------------------------------
		set @select = case
							when @rand <= 0 then '1:0:100;2:-1:0; 3:-1:0; 4:-1:0;'	-- 1�� ����
							when @rand <= 1 then '1:0:100;2:0:100;3:-1:0; 4:-1:0;'	-- 2�� ����
							when @rand <= 2 then '1:0:100;2:0:100;3:0:100;4:-1:0;'	-- 3�� ����
							when @rand <= 3 then '1:0:100;2:0:100;3:0:100;4:0:100;'	-- 4�� ����

							when @rand <= 4 then '1:1:100;2:-1:0; 3:-1:0; 4:-1:0;'	-- 1�� ����
							when @rand <= 5 then '1:1:100;2:1:100;3:-1:0; 4:-1:0;'	-- 2�� ����
							when @rand <= 6 then '1:1:100;2:1:100;3:1:100;4:-1:0;'	-- 3�� ����
							else                 '1:1:100;2:1:100;3:1:100;4:1:100;'	-- 4�� ����
					  end

		-- 1. ����.
		exec dbo.spu_SGBetTest @gameid, '049000s1i0n7t8445289', 333, 1, -1, @curturntime, @select, -1

		-- 2. ���.
		exec dbo.spu_SGResultTest @gameid, '049000s1i0n7t8445289', 333, 1, @curturntime, -1

		-- 3. ������ ���ؼ� ����.
		--delete from dbo.tSingleGame where gameid = @gameid  and curturntime = @curturntime
		--delete from dbo.tSingleGameLog where gameid = @gameid and curturntime = @curturntime

		select @gamecost = gamecost from dbo.tUserMaster where gameid = @gameid
		if(@gamecost >= 400)			
			begin
				Fetch next from curSingleGameSimule into @curturntime
			end
	end
close curSingleGameSimule
Deallocate curSingleGameSimule

